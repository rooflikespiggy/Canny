import 'package:flutter/material.dart';

//background colour
const kBackgroundColour = Color(0xFFEFEBE9);

//for function screen buttons
const kDeepOrange = Colors.deepOrange;
const kDeepOrangePrimary = Color(0xFFFF7043);
const kDeepOrangeLight = Color(0xFFFF8B5C);

//for calculator buttons
const kDarkGrey = Color(0xFF686D7B);

